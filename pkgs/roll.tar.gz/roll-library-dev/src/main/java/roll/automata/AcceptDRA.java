package roll.automata;

public class AcceptDRA implements Accept {
	
	public AcceptDRA(DRA dra) {
		
	}

}
