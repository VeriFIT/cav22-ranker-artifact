package roll.main.complement.algos;

import roll.automata.NBA;
import roll.main.Options;
import roll.main.complement.Complement;

public class ComplementSlice extends Complement {

	public ComplementSlice(Options options, NBA operand) {
		super(options, operand);
		// TODO Auto-generated constructor stub
	}

	@Override
	protected void computeInitialState() {
		// TODO Auto-generated method stub
		
	}

}
