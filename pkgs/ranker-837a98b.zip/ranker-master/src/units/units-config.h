
#ifndef _UNITS_CONFIG_H_
#define _UNITS_CONFIG_H_

#include <string>

std::string RABITEXE = "";
std::string TMPNAME = "tmp124232.ba";

#endif
