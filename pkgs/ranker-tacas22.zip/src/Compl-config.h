
#ifndef _COMPL_CONFIG_H_
#define _COMPL_CONFIG_H_

#include <string>

std::string RABITEXE = "./rabit/RABIT.jar";
std::string GOALEXE = "./gc";

#endif
